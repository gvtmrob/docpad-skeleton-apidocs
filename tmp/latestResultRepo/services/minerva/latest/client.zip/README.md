# Minerva

Browser and node module for making API requests against [Minerva](http://minerva.us-west-2.elasticbeanstalk.com).

**Please note: This module uses [Popsicle](https://github.com/blakeembrey/popsicle) to make API requests. Promises must be supported or polyfilled on all target environments.**

## Installation

```
npm install minerva --save
bower install minerva --save
```

## Usage

### Node

```javascript
var Minerva = require('minerva');

var client = new Minerva();
```

### Browsers

```html
<script src="minerva/index.js"></script>

<script>
  var client = new Minerva();
</script>
```

### Options

You can set options when you initialize a client or at any time with the `options` property. You may also override options for a single request by passing an object as the second argument of any request method. For example:

```javascript
var client = new Minerva({ ... });

client.options = { ... };

client.resource('/').get(null, {
  baseUri: 'http://example.com',
  headers: {
    'Content-Type': 'application/json'
  }
});
```

#### Base URI

You can override the base URI by setting the `baseUri` property, or initializing a client with a base URI. For example:

```javascript
new Minerva({
  baseUri: 'https://example.com'
});
```

#### Base URI Parameters

If the base URI has parameters inline, you can set them by updating the `baseUriParameters` property. For example:

```javascript
client.options.baseUriParameters.version = '0.0.1';
```

### Resources

All methods return a HTTP request instance of [Popsicle](https://github.com/blakeembrey/popsicle), which allows the use of promises (and streaming in node).

#### resources.events

Using this endpoint you can create new event or search for existing ones

```js
var resource = client.resources.events;
```

##### GET

Find events by name or other values. If no query params are set, it returns all the events.

```js
resource.get().then(function (res) { ... });
```

##### Query Parameters

```javascript
resource.get({ ... });
```

* **q** _string_

Query parameters separated with one space.

##### POST

Create new event or organization data.

```js
resource.post().then(function (res) { ... });
```

##### Headers

```javascript
resource.post(null, {
  headers: { ... }
});
```

* **Content-Type** _string_

application/json

##### Body

**application/json**

```
{"type":"object","$schema":"http://json-schema.org/draft-03/schema#","description":"Array of events details.","title":"Event","properties":{"type":{"type":"string","required":true,"title":"type"},"name":{"type":"string","required":true,"title":"name"},"description":{"type":"string","required":true,"title":"description"},"website":{"type":"string","required":false,"title":"website"},"start_date":{"type":"string","required":false,"title":"start_date"},"end_date":{"type":"string","required":false,"title":"end_date"},"address":{"type":"string","required":false,"title":"address"},"latitude":{"type":"number","required":false,"title":"latitude"},"longitude":{"type":"number","required":false,"title":"longitude"},"eventId":{"type":"string","required":true,"title":"eventId"}}}

```

#### resources.events.eventId(eventId)

* **eventId** _string_

Id of specific event or organization

```js
var resource = client.resources.events.eventId(eventId);
```

##### GET

Retrieve data of single event or organization

```js
resource.get().then(function (res) { ... });
```

##### DELETE

Delete specified event or organization

```js
resource.delete().then(function (res) { ... });
```

##### PUT

Updating specific event or organization. It is so called partial update, which means you need to provide only attributes that you want to edit or add

```js
resource.put().then(function (res) { ... });
```

##### Headers

```javascript
resource.put(null, {
  headers: { ... }
});
```

* **Content-Type** _string_

application/json

##### Body

**application/json**

```
{"type":"object","$schema":"http://json-schema.org/draft-03/schema#","description":"Array of events details.","title":"Event","properties":{"type":{"type":"string","required":true,"title":"type"},"name":{"type":"string","required":true,"title":"name"},"description":{"type":"string","required":true,"title":"description"},"website":{"type":"string","required":false,"title":"website"},"start_date":{"type":"string","required":false,"title":"start_date"},"end_date":{"type":"string","required":false,"title":"end_date"},"address":{"type":"string","required":false,"title":"address"},"latitude":{"type":"number","required":false,"title":"latitude"},"longitude":{"type":"number","required":false,"title":"longitude"},"eventId":{"type":"string","required":true,"title":"eventId"}}}

```



### Custom Resources

You can make requests to a custom path in the API using the `#resource(path)` method.

```javascript
client.resource('/example/path').get();
```

## License

Apache 2.0
